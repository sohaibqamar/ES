# eaglelib

This is an Eagle library with footprint and components for:

* LM2596/LM2577/XL6009/XL4015/XL4005 voltage regulator/converter module
* ADE7953 28-pin LFCSP package
* TP4056 5V 1A Lithium Battery Charger + Protection Module
* 18650 Lithium Ion battery housing
